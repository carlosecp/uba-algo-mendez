#include "pa2mm.h"
#include "src/hash.h"
#include "./src/casilla.h"
#include <string.h>

#define EXITO 0
#define ERROR -1

struct hash {
	casilla_t** casillas;
	size_t cantidad_casillas;
	size_t cantidad_elementos;
	hash_destruir_dato_t destruir_elemento;
};

						 /* Auxiliares para pruebas */

typedef struct {
	size_t padron;
	char* nombre;
} estudiante_t;

estudiante_t* crear_estudiante(size_t padron, char* nombre) {
	estudiante_t* est = malloc(sizeof(estudiante_t));
	est->padron = padron;
	est->nombre = nombre;
	return est;
}

void destruir_estudiante(void* est) {
	free(est);
}

bool reprobar_estudiante(hash_t* hash, const char* clave, void* aux) {
	printf("clave: %s\n", clave);
	return true;
}

bool reprobar_hasta_segundo_estudiante(hash_t* hash, const char* clave, void* aux) {
	return !strcmp(clave, "segundo");
}

// === BORRAR ===

void imprimir_casilla(casilla_t* casilla) {
	if (!casilla)
		return;

	estudiante_t est = *(estudiante_t*)casilla->elemento;
	printf(" {%s: {%s, %li}} ", casilla->clave, est.nombre, est.padron);
	imprimir_casilla(casilla->siguiente);
}

void imprimir_hash(hash_t* hash) {
	for (size_t i = 0; i < hash->cantidad_casillas; i++) {
		if (hash->casillas[i] == NULL) {
			printf("\t%li\t---\n", i);
		} else {
			printf("\t%li\t", i);
			imprimir_casilla(hash->casillas[i]);
			printf("\n");
		}
	}
}

						  /* Pruebas Hash: Creacion */

void dadoUnDestructorYUnValorInicialValido_alCrearUnHash_seRetornaUnHashCon0Elementos() {
	hash_t* hash = hash_crear(destruir_estudiante, 3);
	pa2m_afirmar(hash != NULL, "Al crear un hash con un destructor y valor inicial valido, se retorna un hash no NULL");
	pa2m_afirmar(hash_cantidad(hash) == 0, "Al crear un hash la cantidad de elementos es 0");
	hash_destruir(hash);
}

void dadoUnDestructorNULL_alDestruirUnHash_seDestruyeCorrectamenteSinDestruirLosElementos() {
	hash_t* hash = hash_crear(NULL, 5);

	estudiante_t* est0 = crear_estudiante(25, "Alejandro Schamun");
	hash_insertar(hash, "primero", est0);
	hash_destruir(hash);

	pa2m_afirmar(est0 != NULL, "Al destruir un hash con un destructor NULL, solo se destruye el hash, no los elementos");

	if (est0)
		destruir_estudiante(est0);
}

						  /* Pruebas Hash: Insertar */

void dadoUnHashNULL_alInsertarUnElemento_seRetornaError() {
	hash_t* hash = NULL;
	pa2m_afirmar(hash_insertar(hash, "primero", NULL) == ERROR, "Al insertar en un hash NULl se retorna ERROR (-1)");
	hash_destruir(hash);
}

void dadaUnaClaveNULL_alInsertarUnElemento_seRetornaError() {
	hash_t* hash = hash_crear(destruir_estudiante, 3);
	pa2m_afirmar(hash_insertar(hash, NULL, NULL) == ERROR, "Al insertar un elemento con clave NULL se retorna ERROR (-1)");
	hash_destruir(hash);
}

void dadoUnHash_alInsertarVariosElementos_seInsertanCorrectamente() {
	hash_t* hash = hash_crear(destruir_estudiante, 10);

	estudiante_t* est0 = crear_estudiante(25, "Alejandro Schamun");
	estudiante_t* est1 = crear_estudiante(20, "Cami Fiorotto");
	estudiante_t* est2 = crear_estudiante(36, "Carolina Aramay");
	estudiante_t* est3 = crear_estudiante(10, "Facundo Sanso");
	estudiante_t* est4 = crear_estudiante(22, "Joaquin Dopazo");

	pa2m_afirmar(hash_insertar(hash, "primero", est0) == EXITO, "Al insertar un elemento correctamente se retorna EXITO (0)");

	hash_insertar(hash, "segundo", est1);
	hash_insertar(hash, "tercero", est2);
	hash_insertar(hash, "cuarto",  est3);
	hash_insertar(hash, "quinto",  est4);

	pa2m_afirmar(hash_cantidad(hash) == 5, "Al insertar 5 elementos en un hash la cantidad de elementos es 5");

	hash_destruir(hash);
}

void dadoUnHash_alInsertarUnElementoConUnaClaveRepetida_seInsertaCorrectamente() {
	hash_t* hash = hash_crear(destruir_estudiante, 10);

	estudiante_t* est0 = crear_estudiante(25, "Alejandro Schamun");
	estudiante_t* est1 = crear_estudiante(20, "Cami Fiorotto");

	hash_insertar(hash, "primero", est0);

	pa2m_afirmar(hash_insertar(hash, "primero", est1) == EXITO, "Al insertar un elemento con clave repetida se retorna EXITO (0)");
	pa2m_afirmar(hash_cantidad(hash) == 1, "Al insertar un elemento con clave repetida la cantidad de elementos en el hash se mantiene igual");

	hash_destruir(hash);
}

void test_rehash() {
	hash_t* hash = hash_crear(destruir_estudiante, 2);

	estudiante_t* est0 = crear_estudiante(25, "Alejandro Schamun");
	estudiante_t* est1 = crear_estudiante(20, "Cami Fiorotto");
	estudiante_t* est2 = crear_estudiante(36, "Carolina Aramay");
	estudiante_t* est3 = crear_estudiante(10, "Facundo Sanso");
	estudiante_t* est4 = crear_estudiante(22, "Joaquin Dopazo");
	estudiante_t* est5 = crear_estudiante(30, "Julian Calderon");
	estudiante_t* est6 = crear_estudiante(40, "Julian Stiefkens");
	estudiante_t* est7 = crear_estudiante(5,  "Manuel Sanchez");
	estudiante_t* est8 = crear_estudiante(12, "Nicolas Celano");
	estudiante_t* est9 = crear_estudiante(28, "Nicolas Tonizzo");

	hash_insertar(hash, "primero", est0);
	imprimir_hash(hash);
	printf("\n----------------------------------------------\n\n");

	hash_insertar(hash, "segundo", est1);
	imprimir_hash(hash);
	printf("\n----------------------------------------------\n\n");

	hash_insertar(hash, "tercero", est2);
	imprimir_hash(hash);
	printf("\n----------------------------------------------\n\n");

	hash_insertar(hash, "cuarto",  est3);
	imprimir_hash(hash);
	printf("\n----------------------------------------------\n\n");

	hash_insertar(hash, "quinto",  est4);
	imprimir_hash(hash);
	printf("\n----------------------------------------------\n\n");

	hash_insertar(hash, "sexto",   est5);
	imprimir_hash(hash);
	printf("\n----------------------------------------------\n\n");

	hash_insertar(hash, "septimo", est6);
	imprimir_hash(hash);
	printf("\n----------------------------------------------\n\n");

	hash_insertar(hash, "octavo",  est7);
	imprimir_hash(hash);
	printf("\n----------------------------------------------\n\n");

	hash_insertar(hash, "noveno",  est8);
	imprimir_hash(hash);
	printf("\n----------------------------------------------\n\n");

	hash_insertar(hash, "decimo",  est9);
	imprimir_hash(hash);
	printf("\n----------------------------------------------\n\n");

	hash_destruir(hash);
}

						   /* Pruebas Hash: Quitar */

void dadoUnHashNULL_alQuitarUnElemento_seRetornaError() {
	hash_t* hash = NULL;
	pa2m_afirmar(hash_quitar(hash, "clave"), "Al quitar en un hash NULL se devuelve ERROR (-1)");
	hash_destruir(hash);
}

void dadaUnaClaveNULL_alQuitarUnElemento_seRetornaError() {
	hash_t* hash = hash_crear(destruir_estudiante, 3);
	pa2m_afirmar(hash_quitar(hash, NULL) == ERROR, "Al quitar un elemento con clave NULL se retorna ERROR (-1)");
	hash_destruir(hash);
}

void dadoUnHash_alQuitarVariosElementos_seQuitanCorrectamente() {
	hash_t* hash = hash_crear(destruir_estudiante, 3);

	estudiante_t* est0 = crear_estudiante(25, "Alejandro Schamun");
	estudiante_t* est1 = crear_estudiante(20, "Cami Fiorotto");
	estudiante_t* est2 = crear_estudiante(36, "Carolina Aramay");
	estudiante_t* est3 = crear_estudiante(10, "Facundo Sanso");
	estudiante_t* est4 = crear_estudiante(22, "Joaquin Dopazo");
	estudiante_t* est5 = crear_estudiante(22, "Joaquin Dopazo");

	hash_insertar(hash, "primero", est0);

	pa2m_afirmar(hash_quitar(hash, "primero") == EXITO, "Al quitar un elemento correctamente se retorna EXITO (0)");
	pa2m_afirmar(hash_cantidad(hash) == 0, "Al quitar un elemento la cantidad de elementos disminuye");
	pa2m_afirmar(hash_quitar(hash, "no_existe") == ERROR, "Al quitar un elemento con clave que no existe se retorna ERROR (-1)");
	pa2m_afirmar(hash_cantidad(hash) == 0, "Al quitar un elemento con clave que no existe la cantidad no se disminuye");

	hash_insertar(hash, "segundo", est1);
	hash_insertar(hash, "tercero", est2);
	hash_insertar(hash, "cuarto",  est3);
	hash_insertar(hash, "quinto",  est4);
	hash_insertar(hash, "sexto",   est5);

	hash_quitar(hash, "segundo");
	hash_quitar(hash, "tercero");
	hash_quitar(hash, "cuarto");
	hash_quitar(hash, "quinto");
	hash_quitar(hash, "sexto");

	pa2m_afirmar(hash_cantidad(hash) == 0, "Al quitar todos los elementos la cantidad de elementos es 0");

	hash_destruir(hash);
}

						  /* Pruebas Hash: Obtener */

void dadoUnHashNULL_alObtenerUnElemento_seRetornaNULL() {
	hash_t* hash = NULL;
	pa2m_afirmar(hash_obtener(hash, "no_existe") == false, "Al obtener un elemento en un hash NULL se retorna NULL");
	hash_destruir(hash);
}

void dadaUnaClaveNULL_alObtenerUnElemento_seRetornaNULL() {
	hash_t* hash = hash_crear(destruir_estudiante, 3);
	pa2m_afirmar(hash_obtener(hash, "no_existe") == false, "Al obtener un elemento con clave NULL se retorna NULL");
	hash_destruir(hash);
}

void dadoUnHash_alObtenerUnElemento_seObtieneCorrectamente() {
	hash_t* hash = hash_crear(destruir_estudiante, 3);

	estudiante_t* est0 = crear_estudiante(25, "Alejandro Schamun");
	hash_insertar(hash, "primero", est0);

	pa2m_afirmar(hash_obtener(hash, "primero") == est0, "Al obtener un elemento por su clave se retorna el elemento correcto");
	pa2m_afirmar(hash_obtener(hash, "no_existe") == NULL, "Al obtener un elemento que no existe se retorna NULL");

	hash_destruir(hash);
}

						  /* Pruebas Hash: Contiene */

void dadoUnHashNULL_alVerificarSiContieneUnElemento_seRetornaNULL() {
	hash_t* hash = NULL;
	pa2m_afirmar(hash_contiene(hash, "no_existe") == false, "Al verificar si un hash NULL contiene un elemento se retorna false");
	hash_destruir(hash);
}

void dadaUnaClaveNULL_alVerificarSiElHashContieneUnElemento_seRetornaNULL() {
	hash_t* hash = hash_crear(destruir_estudiante, 3);
	pa2m_afirmar(hash_contiene(hash, "no_existe") == false, "Al verificar si un hash contiene un elemento con clave NULL se retorna false");
	hash_destruir(hash);
}

void dadoUnHash_alVerificarSiContieneUnElemento_seObtieneCorrectamente() {
	hash_t* hash = hash_crear(destruir_estudiante, 3);

	estudiante_t* est0 = crear_estudiante(25, "Alejandro Schamun");
	hash_insertar(hash, "primero", est0);

	pa2m_afirmar(hash_obtener(hash, "primero") == est0, "Al verificar si un hash contiene un elemento insertado previamente se retorna true");
	pa2m_afirmar(hash_obtener(hash, "no_existe") == NULL, "Al verificar si un hash contiene un elemento que no existe se retorna false");

	hash_destruir(hash);
}

						  /* Pruebas Hash: Contiene */

void dadoUnHashNULL_alRecorrerLosElementos_seRetorna0() {
	hash_t* hash = NULL;
	pa2m_afirmar(hash_con_cada_clave(hash, reprobar_estudiante, NULL) == 0, "Al recorrer un hash NULL se retorna 0");
	hash_destruir(hash);
}

void dadoUnHash_alRecorrerLosElementos_seRetornaLaCantidadEsperada() {
	hash_t* hash = hash_crear(destruir_estudiante, 5);

	pa2m_afirmar(hash_con_cada_clave(hash, reprobar_estudiante, NULL) == 0, "Al recorrer un hash vacio se recorren 0 elementos");

	estudiante_t* est0 = crear_estudiante(25, "Alejandro Schamun");
	estudiante_t* est1 = crear_estudiante(20, "Cami Fiorotto");
	estudiante_t* est2 = crear_estudiante(36, "Carolina Aramay");
	estudiante_t* est3 = crear_estudiante(10, "Facundo Sanso");
	estudiante_t* est4 = crear_estudiante(22, "Joaquin Dopazo");
	estudiante_t* est5 = crear_estudiante(30, "Julian Calderon");
	estudiante_t* est6 = crear_estudiante(40, "Julian Stiefkens");
	estudiante_t* est7 = crear_estudiante(5,  "Manuel Sanchez");
	estudiante_t* est8 = crear_estudiante(12, "Nicolas Celano");
	estudiante_t* est9 = crear_estudiante(28, "Nicolas Tonizzo");

	hash_insertar(hash, "primero", est0);
	hash_insertar(hash, "segundo", est1);
	hash_insertar(hash, "tercero", est2);
	hash_insertar(hash, "cuarto",  est3);
	hash_insertar(hash, "quinto",  est4);
	hash_insertar(hash, "sexto",   est5);
	hash_insertar(hash, "septimo", est6);
	hash_insertar(hash, "octavo",  est7);
	hash_insertar(hash, "noveno",  est8);
	hash_insertar(hash, "decimo",  est9);

	pa2m_afirmar(hash_con_cada_clave(hash, reprobar_hasta_segundo_estudiante, NULL) == 5, "Al recorrer un hash hasta llegar a cierta clave e interrumpir el recorrido, se recorren la cantidad de elementos correctos");

	hash_destruir(hash);
}

void dadoUnHash_alRecorrerLosElementosConUnaFuncionNULL_seRecorrenTodosLosElementos() {
	hash_t* hash = hash_crear(destruir_estudiante, 5);

	estudiante_t* est0 = crear_estudiante(25, "Alejandro Schamun");
	estudiante_t* est1 = crear_estudiante(20, "Cami Fiorotto");
	estudiante_t* est2 = crear_estudiante(36, "Carolina Aramay");
	estudiante_t* est3 = crear_estudiante(10, "Facundo Sanso");
	estudiante_t* est4 = crear_estudiante(22, "Joaquin Dopazo");

	hash_insertar(hash, "primero", est0);
	hash_insertar(hash, "segundo", est1);
	hash_insertar(hash, "tercero", est2);
	hash_insertar(hash, "cuarto",  est3);
	hash_insertar(hash, "quinto",  est4);

	pa2m_afirmar(hash_con_cada_clave(hash, NULL, NULL) == 5, "Al recorrer un hash con una funcion NULL se recorren todos los elementos");

	hash_destruir(hash);
}

int main() {
	pa2m_nuevo_grupo("Pruebas Hash: Creacion");
	// dadoUnDestructorYUnValorInicialValido_alCrearUnHash_seRetornaUnHashCon0Elementos();
	// dadoUnDestructorNULL_alDestruirUnHash_seDestruyeCorrectamenteSinDestruirLosElementos();
	
	pa2m_nuevo_grupo("Pruebas Hash: Insertar");
	// dadoUnHashNULL_alInsertarUnElemento_seRetornaError();
	// dadaUnaClaveNULL_alInsertarUnElemento_seRetornaError();
	// dadoUnHash_alInsertarVariosElementos_seInsertanCorrectamente();
	// dadoUnHash_alInsertarUnElementoConUnaClaveRepetida_seInsertaCorrectamente();
	test_rehash();

	pa2m_nuevo_grupo("Pruebas Hash: Quitar");
	// dadoUnHashNULL_alQuitarUnElemento_seRetornaError();
	// dadaUnaClaveNULL_alQuitarUnElemento_seRetornaError();
	// dadoUnHash_alQuitarVariosElementos_seQuitanCorrectamente();

	pa2m_nuevo_grupo("Pruebas Hash: Obtener");
	// dadoUnHashNULL_alObtenerUnElemento_seRetornaNULL();
	// dadaUnaClaveNULL_alObtenerUnElemento_seRetornaNULL();
	// dadoUnHash_alObtenerUnElemento_seObtieneCorrectamente();

	pa2m_nuevo_grupo("Pruebas Hash: Contiene");
	// dadoUnHashNULL_alVerificarSiContieneUnElemento_seRetornaNULL();
	// dadaUnaClaveNULL_alVerificarSiElHashContieneUnElemento_seRetornaNULL();
	// dadoUnHash_alVerificarSiContieneUnElemento_seObtieneCorrectamente();

	pa2m_nuevo_grupo("Pruebas Hash: Recorrido");
	// dadoUnHashNULL_alRecorrerLosElementos_seRetorna0();
	// dadoUnHash_alRecorrerLosElementos_seRetornaLaCantidadEsperada();
	// dadoUnHash_alRecorrerLosElementosConUnaFuncionNULL_seRecorrenTodosLosElementos();

    return pa2m_mostrar_reporte();
}
