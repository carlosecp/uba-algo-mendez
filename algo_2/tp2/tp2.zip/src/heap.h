#ifndef HEAP_H__
#define HEAP_H__

#include <stdio.h>

void heapify(void** elementos, size_t cantidad);

#endif
